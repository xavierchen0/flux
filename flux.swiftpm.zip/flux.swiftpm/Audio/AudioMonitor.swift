//
//  AudioMonitor.swift
//  flux
//
//  Created by Xavier Chen on 24/1/26.
//

import AVFoundation
import Foundation
import SwiftUI  // Import SwiftUI to use @AppStorage or other UI utils if needed

@MainActor
@Observable
class AudioMonitor {
    var amplitude: Float = 0.0
    var currentError: AudioError?
    var showError: Bool = false

    private let engine = AVAudioEngine()
    private var isSimulating = false

    func start() async {
        #if DEBUG
            if ProcessInfo.processInfo.environment["XCODE_RUNNING_FOR_PREVIEWS"]
                == "1"
            {
                startSimulation()
                return
            }
        #endif

        guard !engine.isRunning else { return }

        // Permissions
        let isPermissionGranted = await checkPermission()
        guard isPermissionGranted else {
            triggerError(.permissionDenied)
            // Fallback to simulation 
            #if DEBUG
                startSimulation()
            #endif
            return
        }

        // Audio sessions
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(
                .playAndRecord,
                mode: .measurement,
                options: [
                    .mixWithOthers, .defaultToSpeaker,
                    .overrideMutedMicrophoneInterruption,
                ]
            )
            try session.setActive(true)
        } catch {
            print("Session Error: \(error.localizedDescription)")
            triggerError(.sessionActivationFailed)
            return
        }

        // Audio engine
        let inputNode = engine.inputNode
        let format = inputNode.outputFormat(forBus: 0)

        if format.channelCount == 0 || format.sampleRate == 0 {
            print(
                "Audio Input Invalid (Channels: \(format.channelCount), Rate: \(format.sampleRate)). Falling back to simulation."
            )
            #if DEBUG
                startSimulation()
            #endif
            return
        }

        inputNode.removeTap(onBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) {
            [weak self] buffer, _ in
            guard let self = self else { return }

            let level = self.calculateAmplitude(buffer: buffer)

            Task { @MainActor in
                self.amplitude = level
            }
        }

        engine.prepare()

        do {
            try engine.start()
        } catch {
            triggerError(.engineError)
        }
    }

    func stop() {
        isSimulating = false

        if engine.isRunning {
            engine.stop()
        }
        engine.inputNode.removeTap(onBus: 0)

        do {
            try AVAudioSession.sharedInstance().setActive(
                false,
                options: .notifyOthersOnDeactivation
            )
        } catch {
            triggerError(.sessionDeActivationFailed)
        }
    }

    private func startSimulation() {
        guard !isSimulating else { return }
        isSimulating = true

        Task {
            while isSimulating {
                for val in stride(from: 0.2, through: 0.8, by: 0.02) {
                    if !isSimulating { break }
                    self.amplitude = Float(val)
                    try? await Task.sleep(for: .milliseconds(50))
                }

                try? await Task.sleep(for: .seconds(1))

                for val in stride(from: 0.8, through: 0.2, by: -0.02) {
                    if !isSimulating { break }
                    self.amplitude = Float(val)
                    try? await Task.sleep(for: .milliseconds(50))
                }

                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    private func checkPermission() async -> Bool {
        let status = AVAudioApplication.shared.recordPermission
        switch status {
        case .undetermined:
            return await AVAudioApplication.requestRecordPermission()
        case .denied:
            return false
        case .granted:
            return true
        @unknown default:
            return false
        }
    }

    private func triggerError(_ error: AudioError) {
        self.currentError = error
        self.showError = true
    }

    nonisolated private func calculateAmplitude(buffer: AVAudioPCMBuffer)
        -> Float
    {
        guard let channelData = buffer.floatChannelData?[0] else { return 0.0 }
        let frameLength = Int(buffer.frameLength)

        var sum: Float = 0.0
        let step = 4

        for i in stride(from: 0, to: frameLength, by: step) {
            let sample = channelData[i]
            sum += sample * sample
        }

        let mean = sum / Float(frameLength / step)
        let rms = sqrt(mean)

        return min(rms * 5.0, 1.0)
    }
}
